﻿# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import os
import subprocess
import sys
import time
import json
from standalone_spark_utilities import get_master_ip, is_primary_instance, get_spark_home
from spark_env_check import spark_environment_check

import azureml_globals

def _load_env(json_path):
    while not os.path.exists(json_path):
        time.sleep(0.01)
    with open(json_path, 'r') as json_file:
        env = json.load(json_file)
    # Only add env vars that aren't already present to avoid overwriting the per-node env vars that BatchAI sets up.
    for key, value in env.items():
        if key is not None and value is not None and os.environ.get(key) is None:
            os.environ[key] = value

from distributed_settings import configure_distributed_settings
configure_distributed_settings()

setup_path = os.path.abspath("azureml-setup")
master_work_done_marker_path = os.path.join(setup_path, "standalone_spark_done")
master_env_dump_file_path = os.path.join(setup_path, "standalone_spark_master_env_dump.json")
if is_primary_instance():
    try:
        # Basic check of the Spark environment to display better error messages.
        spark_environment_check()
        
        with open(master_env_dump_file_path, 'w') as outfile:
            env_json = dict(os.environ)
            # To prevent credential leak, avoid dumping AZUREML and AZ_BATCH related variables.
            keys_to_drop = []
            for key, value in env_json.items():
                if key.startswith(azureml_globals.env_var_prefix_azureml) or key.startswith(azureml_globals.env_var_prefix_az_batch):
                    keys_to_drop.append(key)
            for key in keys_to_drop:
                del env_json[key]
            json.dump(env_json, outfile)
        subprocess.check_call([get_spark_home() + "/sbin/start-master.sh", "-h",
                               get_master_ip(), "--webui-port", "8080"])
        # Also launch a slave in master node
        subprocess.check_call([get_spark_home() + "/sbin/start-slave.sh",
                               "spark://" + get_master_ip() + ":7077",
                               "--webui-port", "8081"])

        # PySparkInteractive is an experimental and non-customer facing framework.
        if os.environ[azureml_globals.env_var_framework] == azureml_globals.pyspark_interactive_framework_constant:
            from jupyter_utilities import pyspark_interactive_setup
            pyspark_interactive_setup(setup_path)
        else:
            subprocess.check_call(sys.argv[1:])
    finally:
            os.mkdir(master_work_done_marker_path)

else:
    try:
        # Basic check of the Spark environment to display better error messages.
        spark_environment_check()

        _load_env(master_env_dump_file_path)
        subprocess.check_call([get_spark_home() + "/sbin/start-slave.sh",
                               "spark://" + get_master_ip() + ":7077",
                               "--webui-port", "8081"])
    finally:
        while not os.path.exists(master_work_done_marker_path):
            time.sleep(0.01)