# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from log_history_status import set_run_error

import errno
import killable_subprocess
import os
import subprocess
import sys


def docker_execute_function(docker_command, command_args, print_command_args=False, *popen_args, **kwargs):
    command_args = docker_command + command_args
    return killable_subprocess.check_call(command_args, *popen_args,
                                          print_command_args=print_command_args, **kwargs)


# Checks for both docker installation, sudo-less docker configuration and returns the correct command for docker operations.
def get_sudo_docker_command_or_error():
    docker_command = ["docker"]
    if not _get_docker_version() >= '19.03' and _is_nvidia_docker_installed() and _get_gpu_count() > 0:
        docker_command = ["nvidia-docker"]
    try:
        with open(os.devnull, 'w') as devnull:
            # we intentionally call docker images here as we need to check for insufficient permissions.
            subprocess.check_call(docker_command + ["images"], stdout=devnull, stderr=devnull)
            return docker_command
    except (OSError, IOError) as error:
        # if docker is not installed and on the path, we get ENOENT
        # NOTE: in python 3.3, IOError has been merged into OSError. We catch both to support python < 3.3
        if error.errno == errno.ENOENT:
            _docker_error(error)
        else:
            _set_error_on_run(1, error_obj=error)
            raise error
    except subprocess.CalledProcessError as error:
        # we get a non-zero exit status if sudoless docker hasn't been configured.
        # checking whether we can run sudo docker needs to be done only on linux based targets
        if not sys.platform.startswith("linux"):
            _docker_error(error)
        try:
            with open(os.devnull, 'w') as devnull:
                subprocess.check_call(["sudo"] + docker_command + ["images"], stdout=devnull, stderr=devnull)
                return ["sudo"] + docker_command
        except (subprocess.CalledProcessError, OSError, IOError) as error:
            _sudo_error(error)


def _is_nvidia_docker_installed():
    try:
        with open(os.devnull, 'w') as devnull:
            subprocess.check_call(["nvidia-docker"], stdout=devnull, stderr=devnull)
            print("nvidia-docker is installed on the target. Using nvidia-docker for docker operations.")
            return True
    except (OSError, IOError):
        # NOTE: in python 3.3, IOError has been merged into OSError. We catch both to support python < 3.3
        return False
    except subprocess.CalledProcessError:
        # To be safe, we'll assume that nvidia-docker is not installed/configured for other failures.
        return False


def _docker_error(error=None):
    docker_not_installed_msg = "Docker was not found on the target, check that it is installed and on the path."
    _set_error_on_run(1, error_msg=docker_not_installed_msg, error_obj=error)
    sys.exit(1)


def _sudo_error(error=None):
    sudo_error_msg = ('Unable to run docker with sudo. Check that sudo is configured to run docker without a password.'
        ' See http://aka.ms/aml-ttysudoerror for more information.')
    _set_error_on_run(1, error_msg=sudo_error_msg, error_obj=error)
    sys.exit(1)


def _set_error_on_run(exit_code, error_msg=None, error_obj=None):
    if error_obj is not None:
        print(repr(error_obj))

    if error_msg is not None:
        print()
        print(error_msg)
        print()

    error_response = {
        "Error": {
            "Code": "UserError",
            "Message": "Failed to build the docker image with exit code {}. "
                        "Please check azureml-logs/60_control_log.txt for more details.".format(exit_code)
        }
    }
    set_run_error(error_response, caller="docker_command_utilities")

def _get_gpu_count():
    try:
        import subprocess
        return subprocess.check_output(['nvidia-smi', '-L']).decode(encoding='UTF-8').count('\n')
    except:
        return 0

def _get_docker_version():
    try:
        import docker
        return docker.from_env().version()['Components'][0]['Version']
    except:
        return ''
