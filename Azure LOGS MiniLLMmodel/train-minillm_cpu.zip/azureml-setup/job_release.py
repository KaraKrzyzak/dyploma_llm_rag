﻿# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import datetime
# log as early as possible to get a more accurate time of start.
print("[{}] Entering job release".format(datetime.datetime.now().isoformat()))

import argparse
import errno
import os
import zipfile
import subprocess
import time
import sys
import logging


if sys.version_info.major != 3 or sys.version_info.minor < 5:
    raise RuntimeError("Python version " + str(sys.version_info) + " is not supported. Please use python>=3.5")


import azureml_globals
from threading import Event, Thread
import azureml_globals
from utility_context_managers import get_telemetry_client
from azureml_globals import setup_project_dir, get_datastore_context_manager, is_batchai_target_type, in_sidecar
import shutil
from distutils.dir_util import copy_tree
from utility_context_managers import DependencyTimer
from utility_context_managers import SimpleOpTracker
from context_managers import TrackError
from _tracer import get_tracer

try:
    from azureml.core.run import Run
except ImportError:
    pass

_tracer = get_tracer(__name__)

def upload_datastore(telemetry_client, shared, options):
    with _tracer.start_as_current_span('job_release.upload_datastore'):
        try:
            with SimpleOpTracker("job release stage : upload_datastore"):
                datastore_context_manager = get_datastore_context_manager(options)
                if datastore_context_manager:
                    datastore_context_manager.context_manager.timeout_enabled = False
                    datastore_context_manager.context_manager.set_telemetry_client(telemetry_client)
                    datastore_context_manager.__exit__()
        except Exception as err:
            print(err)
            shared['error'] = err


def run_history_release(telemetry_client, shared):
    with _tracer.start_as_current_span('job_release.run_history_release'):
        print("[{}] job release stage : start importing azureml.history._tracking in run_history_release.".format(datetime.datetime.now().isoformat()))

        try:
            from azureml.history._tracking import execute_job_release
        except ImportError:
            return

        try:
            from azureml.history._tracking  import DISABLE_OUTPUT_UPLOAD
        except ImportError:
            # if we are here, there is no switch to disable output upload explicitly
            # For older versions of SDK there is no way to tell SDK to not upload outputs.
            # Double upload results in run failure.
            # Therefore, as a work around set OUTPUTS_DIR to a non existent folder (random guid).
            import uuid
            import azureml.history._tracking
            azureml.history._tracking.OUTPUTS_DIR = "azureml_{}".format(str(uuid.uuid4()))

        try:
            with SimpleOpTracker("job release stage : execute_job_release"):
                with DependencyTimer(name="RunHistoryJobRelease", telemetry_client=telemetry_client):
                    config = {"disable_output_upload": True}
                    if not is_batchai_target_type:
                        config["DirectoriesToWatch"] = os.path.join("logs","azureml", "job_release_azureml.log")
                    execute_job_release(**config)
        except Exception as err:
            print(err)
            shared['error'] = err


def get_return_code(status):
    if status.lower() == "succeeded":
        return 0
    return 1

def send_run_telemetry(telemetry_client, current_time):
    with _tracer.start_as_current_span('job_release.send_run_telemetry'):
        try:
            with SimpleOpTracker("job release stage : send_run_telemetry"):
                run_duration_sec = -1
                run_starttime_file = azureml_globals.get_run_starttime_filepath()
                if os.path.exists(run_starttime_file):
                    with open(run_starttime_file, "r") as file:
                        start = file.read()
                        start_time = float(start)
                        run_duration_sec = current_time - start_time
                from run_script import send_compute_usage_telemetry
                result_status = os.environ.get(azureml_globals.env_var_az_batchai_run_status)
                if result_status:
                    return_code = get_return_code(result_status)
                    with DependencyTimer(name="ResourceUsageTelemetry", suppress_logging=True,
                                         swallow_errors=True, telemetry_client=telemetry_client):
                        send_compute_usage_telemetry(return_code, result_status, run_duration_sec, None, telemetry_client)
                else:
                    print("[{}] Job release stage : send_run_telemetry WARNING : Environment variable {} is not set".format(datetime.datetime.now().isoformat(), azureml_globals.env_var_az_batchai_run_status))
        except Exception as ex:
            print(ex)


def safe_makedirs(directory_path):
    try:
        os.makedirs(directory_path, exist_ok=True)
    except OSError as ex:
        if ex.errno != errno.EEXIST:
            raise

def copy_batchai_cached_logs():
    with _tracer.start_as_current_span('job_release.copy_batchai_cached_logs'):
        try:
            # copy batch AI logs to working dir for troubleshooting if log upload failed
            with SimpleOpTracker("job release stage : copy_batchai_cached_logs"):
                log_dir = os.environ.get(azureml_globals.env_var_az_batchai_stdouterr_dir)
                upload_failed = os.environ.get(azureml_globals.env_var_az_batchai_log_upload_failed)
                node_id = os.environ.get(azureml_globals.env_var_az_batch_node_id)
                if upload_failed and upload_failed.lower() == "true":
                    if log_dir and os.path.exists(log_dir):
                        logs_in_cwd = os.path.realpath(log_dir).startswith(os.getcwd())
                        if not logs_in_cwd:
                            print("AzureML compute log upload failed. Copying the logs from {} to the run's working directory {}.".format(log_dir, os.getcwd()))
                            temp_path = os.path.abspath(os.path.join("azureml_compute_logs", node_id))
                            print("Creating directory: {}".format(temp_path))
                            safe_makedirs(temp_path)
                            print("Copying from {} to {}".format(log_dir, temp_path))
                            copy_tree(log_dir, temp_path)
                        else:
                            print("AzureML compute log upload failed. Not copying the logs because AzureML compute log directory {} is already in the working directory {}.".format(log_dir, os.getcwd()))
        except Exception as ex:
            print(ex)


def sidecar_release():
    with _tracer.start_as_current_span('job_release.sidecar_release'):
        print("[{}] Running in AzureML-Sidecar, starting to exit user context managers...".format(datetime.datetime.now().isoformat()))
        pre_args = sys.argv
        import json
        sidecar_release_cmd = json.loads(os.environ.get('AZUREML_SIDECAR_RELEASE_CMD'))
        sys.argv = sidecar_release_cmd
        import runpy
        print("[{}] Running Sidecar release cmd...".format(datetime.datetime.now().isoformat()))
        runpy.run_module(sidecar_release_cmd[0], run_name='__main__', alter_sys=True)
        print("[{}] Ran Sidecar release cmd.".format(datetime.datetime.now().isoformat()))
        sys.argv = pre_args


def invoke():
    if not azureml_globals.az_batch_is_current_node_master:
        copy_batchai_cached_logs()
        # IF IN SIDECAR, EXIT USER CONTEXT MANAGERS EVEN ON NON-MASTER
        if in_sidecar:
            sidecar_release()
        sys.exit(0)

    argument_parser = argparse.ArgumentParser()
    argument_parser.add_argument('-i', '--inject', action='append', default=[])
    options = argument_parser.parse_args()

    print("[{}] Starting job release".format(datetime.datetime.now().isoformat()))
    current_time = time.time()

    # CHANGE CWD
    azureml_globals.setup_project_dir()

    telemetry_client = get_telemetry_client()
    upload_datastore_shared_obj = {'error':None}
    runhistory_release_shared_obj = {'error':None}

    parallelJobs = []

    if azureml_globals.target_type == azureml_globals.batchai_target_type:
        parallelJobs.append(Thread(target=finalizing, args=(telemetry_client, current_time)))

    # DATA STORE UPLOAD
    parallelJobs.append(Thread(target=upload_datastore, args=(telemetry_client, upload_datastore_shared_obj, options)))

    # RUN HISTORY CLEANUP
    parallelJobs.append(Thread(target=run_history_release, args=(telemetry_client, runhistory_release_shared_obj,)))

    parallelJobs.append(Thread(target=copy_batchai_cached_logs))

    for j in parallelJobs:
        j.start()

    # Ensure all of the threads have finished
    for j in parallelJobs:
        j.join()

    if upload_datastore_shared_obj['error']:
        raise upload_datastore_shared_obj['error']
    if runhistory_release_shared_obj['error']:
        raise runhistory_release_shared_obj['error']

    # IF IN SIDECAR, EXIT USER CONTEXT MANAGERS
    if in_sidecar:
        sidecar_release()

    print("[{}] Job release is complete".format(datetime.datetime.now().isoformat()))

def finalizing(telemetry_client, current_time):
    # SET STATUS TO FINALIZING
    try:
        from log_history_status import log_finalizing
        log_finalizing(caller="job_release")
    except Exception as ex:
        print("Error occurred when setting run status to Finalizing: {}".format(ex))

    # SEND TELEMETRY
    send_run_telemetry(telemetry_client, current_time)

if __name__ == "__main__":
    from utility_context_managers import TimeoutHandler
    with _tracer.start_as_current_span('job_release.__main__', user_facing_name='Job release'):
        with TrackError(error_message_prefix = "Job release failed: ", check_user_error_by_type = True, is_compliant=True):
            with TimeoutHandler("JobRelease", azureml_globals.job_release_timeout_sec, azureml_globals.env_var_job_release_timeout):
                invoke()


