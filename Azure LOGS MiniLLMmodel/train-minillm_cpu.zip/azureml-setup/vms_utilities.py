# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import os
import subprocess
from azure.storage.blob import BlobClient
from azure.core.credentials import TokenCredential
from azure.core.credentials import AccessToken
import time

class CustomTokenCredential(TokenCredential):
    def __init__(self, token):
        self._token = token

    def get_token(self, *scopes):
        # return the object with the token and its expiry
        return AccessToken(self._token, int(time.time()) + 3600)

def run_command(command, print_command=True, input=None):
    formatted_command = command.split(" ")

    if print_command:
        print("#### Running command: {}".format(command))
        try:
            result = subprocess.check_output(formatted_command, input=input)
            print(result.decode('utf-8'))
        except subprocess.CalledProcessError as ex:
            print("Call failed with error:\n" + ex.output.decode('utf-8'))
            raise ex
    else:
        print("#### Running command: REDACTED")
        try:
            result = subprocess.check_output(formatted_command, input=input)
        except subprocess.CalledProcessError as ex:
            print("#### Call failed with error: REDACTED")
            raise ex
    return result

def generate_sbom(scan_object_filename, full_image_name, blob_url, url_credentials, digest, blob_container_name):
    print("#### Generating SBOM ")
    print(f"#### Image digest: {digest}")
    print(f"#### Image name: {full_image_name}")
    run_command(f"trivy image --no-progress --format spdx-json --skip-db-update --skip-java-db-update --offline-scan --output {scan_object_filename} {full_image_name} --timeout 10m0s")

    creds_object = CustomTokenCredential(url_credentials)
            
    print("#### Creating blob client")
    print(f"#### Blob URL: {blob_url}") # this has no credentials, fine to print
    client = BlobClient(account_url=blob_url, container_name=blob_container_name, blob_name=f"{digest}/{scan_object_filename}", credential=creds_object)

    print("#### Copying JSON to blob")
    # upload SBOM to blob
    with open(scan_object_filename, mode="rb") as data:
        client.upload_blob(data, overwrite=True)
