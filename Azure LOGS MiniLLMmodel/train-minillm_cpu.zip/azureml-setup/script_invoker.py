# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import os

import killable_subprocess


def invoke_command(script_path, sudo=False, **kwargs):
    if os.name == "nt":
        command = ["cmd.exe", "/c", "{0}".format(script_path)]
    else:
        command = ["/bin/bash", "{0}".format(script_path)]
        command = ["sudo"] + command if sudo else command
    killable_subprocess.check_call(command, **kwargs)
