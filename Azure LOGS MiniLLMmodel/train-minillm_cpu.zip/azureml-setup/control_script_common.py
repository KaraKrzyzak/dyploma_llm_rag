import sys
import subprocess
import os
from threading import Event, Thread

import azureml_globals
from execution_timer import ExecutionTimer
from log_history_status import log_preparing, log_running, log_completed, log_failed, log_canceled, log_error
from upload_artifacts import tail_upload_artifact


LOCAL_CONTROL_SCRIPT = "local"
DOCKER_CONTROL_SCRIPT = "docker"
HDI_CONTROL_SCRIPT = "hdi"

_CONTROL_LOG_LOCATION = "azureml-logs/60_control_log.txt"


def control_script_decorator(control_script_type):
    """Decorator around control function.

    :return:
    :rtype: object
    """
    def actual_decorator(test_function):
        def wrapper(*args, **kwargs):
            azureml_globals.write_pid_to_pidfile()

            control_log_wait_handle = None
            control_log_uploader = None
            success = False
            try:

                control_log_wait_handle = Event()
                control_log_uploader = Thread(
                    target=tail_upload_artifact,
                    args=(
                    azureml_globals.control_log_path, _CONTROL_LOG_LOCATION, control_log_wait_handle,))
                control_log_uploader.start()
                ret_value = test_function(*args, **kwargs)
                success = True
                return ret_value
            except KeyboardInterrupt:
                print("Run interrupted by cancellation or because max duration exceeded.")
                log_canceled(caller="control_script_common")
                log_error("Run interrupted by cancellation or because max duration exceeded.", error_code="UserError", caller="control_script_common")
                sys.exit(1)
            except subprocess.CalledProcessError as ex:
                # Don't print stack traces for failed subcommands -- they're useless.
                if ex.returncode == 255 and os.environ.get("AZUREML_LOCALRUN", "false") == "true":
                    log_error("Local execution of User Script failed. Details can be found in {} log file.".format(_CONTROL_LOG_LOCATION), error_code='UserError', caller="control_script_common")
                else:
                    log_error("Failed to run {} \n Exit code {} \n"
                              "Details can be found in {} log file.".format(ex.cmd, ex.returncode, _CONTROL_LOG_LOCATION), caller="control_script_common")
                sys.exit(1)
            except Exception as ex:
                # For local run it starts artifacts uploading thread after validation of Python version
                # in context_manager_injector.py, move import to be on-demand place to let tail_upload_artifact
                # setup firstly.
                from context_manager_injector import LocalUserScriptException
                if isinstance(ex, LocalUserScriptException):
                    log_error("{} Details can be found in {} log file.".format(ex.message, _CONTROL_LOG_LOCATION),
                              error_code='UserError', caller="control_script_common")
                    raise
                else:
                    print(ex)
                    log_error("Exception while controlling run:\n {}"
                              "\n Details can be found in {} log file.".format(ex, _CONTROL_LOG_LOCATION), caller="control_script_common")
                    raise
            except SystemExit as ex:
                log_error("SystemExit: {}".format(ex.code), caller="control_script_common")
                raise
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
                if control_log_uploader is not None:
                    print("\nUploading control log...")
                    control_log_wait_handle.set()
                    control_log_uploader.join()

                print("Sending final run history status...")
                if success:
                    log_completed(caller="control_script_common")
                else:
                    log_failed(caller="control_script_common")

                ExecutionTimer.log_timers_to_file(ExecutionTimer.CONTROL_TIMER_LOG_PATH)
                os.remove(azureml_globals.pidfile_path)

                print("Control script execution completed")
        return wrapper

    return actual_decorator
