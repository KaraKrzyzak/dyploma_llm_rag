# This script is responsible for running multiple pipeline nodes as a single job on compute.
# Pipeline orchestrator can merge multiple runs depending on docker image used and other factors
# and create a new composite run. This run contains metadata for all merged jobs and uses this
# script then goes through each merged job and sets up the data reference environment variables,
# downloads job snapshot and executes the job. Please see design spec for more details on how this script is used:
# https://msdata.visualstudio.com/Vienna/_git/specs?path=%2FExperimentation%2Fpipeline-node-coalescing.md&version=GBmaster
import datetime
import json
import os
import re
import runpy
import sys

import azureml_globals
import project_fetcher
import run_script
from log_history_status import log_preparing, log_running, log_completed, log_failed, log_canceled

composite_run_id = azureml_globals.run_id
print('Composite run id:', composite_run_id)

input_dir = azureml_globals.get_input_dir()
composite_run_dir = os.path.join(input_dir, composite_run_id)
print('Working dir:', composite_run_dir)

if not os.path.exists(composite_run_dir):
    raise Exception('Working directory for composite run {} not properly set up'.format(composite_run_id))

dataset_name_regex = re.compile(r'^DatasetConsumptionConfig:(.*)$')

def _replace_dataset_args(arg):
    match = dataset_name_regex.match(arg)
    if match is None:
        return arg
    else:
        dataset_name = match.group(1).strip()
        return os.environ.get(dataset_name.upper())

def _update_data_reference_for_node(node_id, data_ref_name):
    env_var_name = "AZUREML_DATAREFERENCE_{0}".format(data_ref_name)
    node_prefixed_env_var_name = "AZUREML_DATAREFERENCE_{0}_{1}".format(node_id, data_ref_name)
    os.environ[env_var_name] = os.environ.get(node_prefixed_env_var_name)
 
def _update_dataset_for_node(node_id, dataset_name):
    # dataset env vars are added with 3 different names
    _update_data_reference_for_node(node_id, dataset_name)
    node_prefixed_name = "{0}_{1}".format(node_id, dataset_name)
    os.environ[dataset_name] = os.environ.get(node_prefixed_name)
    os.environ[dataset_name.upper()] = os.environ.get(node_prefixed_name.upper())

def _build_command_line(run_configuration):
    python_path = os.environ.get('AZUREML_PYTHON_INTERPRETER_PATH')
    setup_path = os.path.join('..', 'azureml-setup')
    run_script_path = os.path.join(setup_path, 'run_script.py')
    context_manager_injector_path = os.path.join(setup_path, 'context_manager_injector.py')

    # Dataset bug 550524 where mounting a dataset multiple times fails
    context_manager_injector_args = os.environ.get('AZUREML_CONTEXT_MANAGER_INJECTION_ARGS') \
        .replace('-i Dataset:context_managers.Datasets', '').split()

    arguments = [_replace_dataset_args(arg) for arg in run_configuration['Arguments']]

    return [
        run_script_path,
        python_path,
        context_manager_injector_path,
        *context_manager_injector_args,
        run_configuration['Script'],
        *arguments,
    ]

def _execute_step_run(step_run):
    node_id = step_run['NodeId']
    step_run_id = step_run['RunId']
    run_definition = step_run['RunDefinition']
    run_configuration = run_definition['Configuration']
    snapshot_id = run_definition['SnapshotId']

    print()
    print('Starting run {} with snapshot id {}. Current time is {}'.format(
        step_run_id, snapshot_id, datetime.datetime.now().isoformat()))

    print('Change run context to run id', step_run_id)
    os.environ["AZUREML_RUN_ID"] = step_run_id
    azureml_globals.run_id = step_run_id

    log_preparing(caller="pipeline_composite_job_runner")

    print('Creating working directory for run:', step_run_id)
    os.mkdir(step_run_id)
    os.chdir(step_run_id)

    # each step run has its own log directory
    print('Creating directory for logs:', azureml_globals.log_directory_path)
    os.mkdir(azureml_globals.log_directory_path)

    print('Setup data references for step')
    if ('DataReferences' in run_configuration):
        data_references = run_configuration['DataReferences']
        if (isinstance(data_references, dict)):
            for data_ref_name in data_references.keys():
                _update_data_reference_for_node(node_id, data_ref_name)

    print('Setup datasets for step')
    if ('Data' in run_configuration):
        datasets = run_configuration['Data']
        if (isinstance(datasets, dict)):
            for dataset_name, dataset in datasets.items():
                if 'EnvironmentVariableName' in dataset:
                    dataset_name = dataset['EnvironmentVariableName']
                _update_dataset_for_node(node_id, dataset_name)

    print('Setup environment variables for step')
    if ('Environment' in run_configuration):
        if ('EnvironmentVariables' in run_configuration['Environment']):
            env_vars = run_configuration['Environment']['EnvironmentVariables']
            if (isinstance(env_vars, dict)):
                for key, value in env_vars.items():
                    os.environ[key] = value

    print('Retrieving project from snapshot:', snapshot_id)
    project_fetcher.fetch_project_snapshot(snapshot_id, path_stack=["."])

    command = _build_command_line(run_configuration)

    print('Executing command:', command)
    sys.argv = command

    sys.stdout.flush()
    sys.stderr.flush()
    
    log_running(caller="pipeline_composite_job_runner")

    try:
        runpy.run_path(sys.argv[0], globals(), run_name='__main__')
        return_code = 0
    except SystemExit as ex:
        print("Error while executing step run:", ex)
        return_code = ex.code if ex.code is not None else 0
    except BaseException as ex:
        print("Error while executing step run:", ex)
        return_code = 1

    if return_code == 0:
        log_completed(caller="pipeline_composite_job_runner")
    else:
        log_failed(caller="pipeline_composite_job_runner")

    return return_code

def invoke(composite_runs_metadata):
    print('Start running composite jobs. Current time is', datetime.datetime.now().isoformat())

    step_runs = composite_runs_metadata['CombinedRuns']
    print('Count of step runs:', len(step_runs))

    for step_run in step_runs:
        # always start in top level directory
        os.chdir(composite_run_dir)

        return_code = _execute_step_run(step_run)

        # TODO: handle continue_on_step_failure
        if return_code != 0:
            sys.exit(return_code)

    print('Finished running composite jobs. Current time is', datetime.datetime.now().isoformat())


if __name__ == '__main__':
    with open('./metadata.json') as f:
        metadata = json.load(f)

    invoke(metadata)