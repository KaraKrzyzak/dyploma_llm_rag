# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import os

import azureml_globals


# Function that conducts a basic check of the PySpark environment to display more informative error messages to users.
def spark_environment_check():
    # NOTE: Don't need to worry about lower/upper cases here as serialization/deserialization of json takes
    #       care of case-normalization and sets them to the right enums as defined in the services' contracts.
    if os.environ.get(azureml_globals.env_var_framework) in azureml_globals.pyspark_frameworks:
        if azureml_globals.env_var_spark_home not in os.environ:
            raise RuntimeError("${} is not set in the target environment. Please make sure {} "
                               "is installed correctly on the target environment.".format(azureml_globals.env_var_spark_home,
                               azureml_globals.pyspark_framework_constant))

        spark_home = os.path.expandvars("${0}".format(azureml_globals.env_var_spark_home))
        spark_submit = os.path.join(spark_home, "bin/spark-submit")
        if not os.path.isfile(spark_submit):
            raise FileNotFoundError("Could not find: '{}'. Please make sure {} is installed correctly "
                                    "in: '{}' on the target environment.".format(spark_submit,
                                    azureml_globals.pyspark_framework_constant, spark_home))
