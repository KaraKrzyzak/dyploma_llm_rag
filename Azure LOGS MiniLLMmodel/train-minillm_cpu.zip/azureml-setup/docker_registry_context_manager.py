# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import docker_utilities


# Helper context manager that handles the login/logout to the specified docker registry
class DockerRegistryContextManager(object):
    def __init__(self, docker_command, docker_address, docker_username, docker_password):
        self.docker_command = docker_command
        self.docker_image_address = docker_address
        self.docker_image_username = docker_username
        self.docker_image_password = docker_password

    def __enter__(self):
        # login to the registry
        if self.docker_image_username is not None and self.docker_image_password is not None:
            print("Logging into Docker registry{}".format(
                ": " + self.docker_image_address if self.docker_image_address else ""))
            docker_utilities.docker_login(
                docker_command=self.docker_command,
                docker_image_username=self.docker_image_username,
                docker_image_password=self.docker_image_password,
                docker_image_address=self.docker_image_address
            )
        return self

    def __exit__(self, *args):
        # logout from the registry
        if self.docker_image_username is not None and self.docker_image_password is not None:
            print("Logging out of Docker registry{}".format(
                ": " + self.docker_image_address if self.docker_image_address else ""))
            docker_utilities.docker_logout(self.docker_command)
