﻿# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import os

import azureml_globals


def get_master_ip():
    master_ip_str = azureml_globals.az_batch_master_node
    if not master_ip_str:
        raise ValueError('Failed to get azure batch cluster master node IP address from BatchAI.')

	# master_ip_str can be of <ip>:<port> or just <ip> depending on which env var the value comes from.
    if ":" in master_ip_str:
        master_ip_pair = master_ip_str.split(':')
        if len(master_ip_pair) != 2:
            raise ValueError('Invalid azure batch master node IP address and port number.')
        return master_ip_pair[0]
    else:
        return master_ip_str
    
def is_primary_instance():
    is_secondary_instance = os.environ.get(azureml_globals.env_var_secondary_instance)
    return is_secondary_instance != "True"


def get_spark_home():
    spark_home = os.environ.get(azureml_globals.env_var_spark_home)
    if not spark_home:
        raise ValueError('Environment variable {0} is not defined in docker image.'.format(azureml_globals.env_var_spark_home))
    return spark_home
