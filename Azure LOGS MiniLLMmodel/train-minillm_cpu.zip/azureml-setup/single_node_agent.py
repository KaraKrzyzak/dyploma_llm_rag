﻿# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import argparse
import json
import os
import subprocess
import sys
import time
import zipfile
import shutil
from threading import Event, Thread
import json
from distutils.dir_util import copy_tree

# We cannot use azureml_globals or other scripts before unzipping.
run_id = os.environ.get("AZUREML_RUN_ID")
target_type = os.environ.get("AZUREML_TARGET_TYPE")
log_directory_path = os.environ.get("AZUREML_LOGDIRECTORY_PATH")
control_script_name = "ControlScript"
control_log_path = os.environ.get("AZUREML_CONTROLLOG_PATH")
job_prep_name = "JobPrep"
job_prep_log_path = os.environ.get("AZUREML_JOBPREPLOG_PATH")
job_release_name = "JobRelease"
job_release_log_path = os.environ.get("AZUREML_JOBRELEASELOG_PATH")
env_var_log_wait_timeout_sec = "AZUREML_CONTROLLOG_WAIT_TIMEOUT_SEC"
log_timeout_sec = int(os.getenv(env_var_log_wait_timeout_sec, "300"))


def _ensure_directory_exists(directory):
    if not os.path.exists(directory):
        print("Creating directory: {}".format(directory))
        os.mkdir(directory)

def start_log_uploader(log_path, log_number):
    project_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), run_id)
    setup_path = os.path.join(project_dir, "azureml-setup")
    sys.path.append(setup_path)
    os.chdir(project_dir)

    from upload_artifacts import tail_upload_artifact

    log_wait_handle = Event()
    log_error = {"error": None}
    remote_log_path = "azureml-logs/{}_{}".format(log_number, os.path.basename(log_path))
    log_uploader = Thread(target=tail_upload_artifact,
                          args=(log_path,
                                remote_log_path,
                                log_wait_handle,
                                log_error,))
    log_uploader.daemon = True
    log_uploader.start()
    return log_uploader, log_error, log_wait_handle

def run_and_log(commands, step_name, log_path, log_number, stream_logs_during_execution):
    '''
    :param commands: list of commands to execute where each command is a list of strings
    :type commands: [[str]]
    :param step_name: name of the current step, used for logging purposes
    :type step_name: str
    :param log_path: path to the log file of the current step
    :type log_path: str
    :param log_number: number prefix for the log file
    :type log_number: int
    :param stream_logs_during_execution: streams logs during command execution if True,
        otherwise sends logs after the commands are finished.
    :type stream_logs_during_execution: bool
    '''
    _ensure_directory_exists(log_directory_path)
    log_wait_handle = None
    log_uploader = None
    with open(log_path, "w") as log_file:
        try:
            sys.stdout = log_file
            sys.stderr = log_file
            if stream_logs_during_execution:
                # if setup is not completed we need to wait until after unzipping our files
                log_uploader, log_error, log_wait_handle = start_log_uploader(os.path.abspath(log_path), log_number)
            # Flush to get logging up to this point written to logs before logging from subprocess
            sys.stdout.flush()
            sys.stderr.flush()

            # Make sure inheritable file descriptors are opened in child process
            # by explicitly setting close_fds=False
            for command in commands:
                command = [os.path.expandvars(c) for c in command]
                subprocess.check_call(command, stdout=log_file, stderr=subprocess.STDOUT, close_fds=False)
        except subprocess.CalledProcessError as ex:
            # Don't print stack traces for failed subcommands -- they're useless.
            sys.exit(1)
        except Exception as ex:
            print(ex)
            raise
        finally:
            if not stream_logs_during_execution:
                log_uploader, log_error, log_wait_handle = start_log_uploader(os.path.abspath(log_path), log_number)

            telemetry_client = None
            try:
                # Technically, this is a lie. After all, we still have a little to do.
                # But tests expect this line to show up in the diagnostic zip, so we have to write it before
                # we actually zip it up.
                print("Control script execution completed")

                # For this reason, we also have to flush the buffer.
                log_file.flush()

                sys.stdout.flush()
                sys.stderr.flush()
                # Since we are stopping the log uploader, redirect to stdout/stderr
                # to avoid any subsequent logging missing from RunHistory
                sys.stdout = sys.__stdout__
                sys.stderr = sys.__stderr__

                if log_uploader is not None:
                    print("\nUploading log file {}...".format(log_path))
                    from utility_context_managers import get_telemetry_client, DependencyTimer, TimeoutHandler
                    telemetry_client = get_telemetry_client()
                    failure_message = "Full logs can be accessed in the file share directly."
                    with DependencyTimer(name="{}LogUpload".format(step_name), target=log_path,
                                         message=failure_message, telemetry_client=telemetry_client):
                        with TimeoutHandler(operation_name="LogUpload".format(step_name),
                                            timeout_sec=log_timeout_sec,
                                            timeout_envvar=env_var_log_wait_timeout_sec):
                            log_wait_handle.set()
                            log_uploader.join()
                            if log_error["error"]:
                                error = log_error["error"]
                                raise error[0].with_traceback(error[1], error[2])

            except Exception as ex:
                print(ex)
                raise

if __name__ == "__main__":
    argument_parser = argparse.ArgumentParser()
    argument_parser.add_argument('--command-args', default=None, required=True)
    options = argument_parser.parse_args()

    if target_type == "container":
        # ACI doesn't accept chained commands separated by semicolon.
        # Instead we provide the commands in JSON-serialized format.
        # Each step can contain multiple commands, each of which are represented as a list of strings.
        all_commands = json.loads(options.command_args)

        run_and_log(all_commands.get(job_prep_name), job_prep_name, job_prep_log_path, 65, stream_logs_during_execution=False)
        run_and_log([all_commands.get(control_script_name)], control_script_name, control_log_path, 55, stream_logs_during_execution=True)
        run_and_log(all_commands.get(job_release_name), job_release_name, job_release_log_path, 75, stream_logs_during_execution=True)
