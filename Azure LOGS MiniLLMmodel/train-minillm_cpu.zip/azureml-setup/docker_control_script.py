﻿# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import argparse
import os
import subprocess
import sys

from execution_timer import ExecutionTimer
from error_utilities import get_error_response_from_stream_or_error, FailedToParseErrorResponseError
from log_history_status import log_preparing, log_running, log_completed, log_failed, log_canceled, set_run_error
from script_invoker import invoke_command
import control_script_common

import azureml_globals
import docker_command_utilities
import interrupt_sender
import project_fetcher
import json


@control_script_common.control_script_decorator(control_script_common.DOCKER_CONTROL_SCRIPT)
def main():

    argument_parser = argparse.ArgumentParser()
    argument_parser.add_argument("--check-script", required=True)
    argument_parser.add_argument("--build-script", required=True)
    argument_parser.add_argument("--error-file-path", required=True)
    argument_parser.add_argument("--shared-volumes", action="store_true", default=False)
    argument_parser.add_argument("--shm-size", default=None)
    argument_parser.add_argument("--ports", default=None)
    argument_parser.add_argument("--tag", required=True)
    argument_parser.add_argument("--max-run-duration", default=None)
    argument_parser.add_argument("docker_invocation", nargs=argparse.REMAINDER)
    argument_parser.add_argument("--snapshots", default=None)
    argument_parser.add_argument("--project-zip", default=None)
    argument_parser.add_argument("--privileged", action="store_true", default=True)
    options = argument_parser.parse_args()

    interrupt_sender.start(options.max_run_duration)

    docker = docker_command_utilities.get_sudo_docker_command_or_error()

    cwd = os.getcwd()
    try:
        env_check_script_path = os.path.join(cwd, options.check_script)
        invoke_command(env_check_script_path, print_command_args=True, cwd=cwd)
    except subprocess.CalledProcessError:
        log_preparing(caller="docker_control_script")
        try:
            with ExecutionTimer("PrepareDockerEnvironment"):
                prepare_env_script_path = os.path.join(cwd, options.build_script)
                invoke_command(prepare_env_script_path, print_command_args=True, cwd=cwd)
        except subprocess.CalledProcessError as ex:
            error_response = {
                "Error": {
                    "Code": "UserError",
                    "Message": ("Failed to build docker image with exit code: {}. "
                                "Please check azureml-logs/60_control_log.txt for more details.").format(ex.returncode)
                }
            }
            error_file_path = os.path.join(cwd, options.error_file_path)
            if os.path.isfile(error_file_path):
                try:
                    with open(error_file_path, "r") as error_file:
                        error_response = get_error_response_from_stream_or_error(error_file)
                except FailedToParseErrorResponseError:
                    # if we can't parse the error message, we'll default to the generic error_response
                    pass
            set_run_error(error_response, caller="docker_control_script")
            raise ex

    if options.snapshots:
        for snapshot in json.loads(options.snapshots):
            project_fetcher.fetch_project_snapshot(snapshot["Id"], snapshot["PathStack"])

    if options.project_zip:
        project_fetcher.fetch_project_zip(options.project_zip)

    ports = []
    if options.ports:
        ports = options.ports.split(",")

    if not options.shared_volumes:
        print("Warning: The sharedVolumes setting in the compute target file is set to false. "
              "Setting it to true will provide better performance. For more details: "
              "https://aka.ms/azureml-sharedvolumes")
        print("")

    try:
        log_running(caller="docker_control_script")

        command = []
        if options.shared_volumes:
            command += ["run"]
        else:
            command += ["create"]

        command += ["--name", azureml_globals.run_id]

        for port in ports:
            command += ["-p", port + ":" + port]

        if options.shared_volumes:
            command += ["--rm", "-v", os.getcwd() + ":/azureml-run"]

        if options.shm_size:
            command += ['--shm-size', options.shm_size]

        if options.privileged:
            command += ["--privileged"]

        if 'nvidia-docker' not in docker and docker_command_utilities._get_gpu_count() > 0:
            command += ["--gpus", "all"]

        # The docker invocation begins with a placeholder value to work with argparse.REMAINDER.
        command += options.docker_invocation[1:]

        def run_interrupted():
            with ExecutionTimer("DockerKill"):
                docker_command_utilities.docker_execute_function(docker, ["kill", azureml_globals.run_id])

        with ExecutionTimer("DockerRun"):
            try:
                if options.shared_volumes:
                    docker_command_utilities.docker_execute_function(docker, command, print_command_args=True, interrupt_handler=run_interrupted)
                else:
                    docker_command_utilities.docker_execute_function(docker, command, print_command_args=True)

                    copy = ["cp", "./.", azureml_globals.run_id + ":/azureml-run/"]
                    docker_command_utilities.docker_execute_function(docker, copy, print_command_args=True)

                    start = ["start", "-a", azureml_globals.run_id]
                    docker_command_utilities.docker_execute_function(docker, start, print_command_args=True, interrupt_handler=run_interrupted)
            except subprocess.CalledProcessError as ex:
                if ex.returncode == 125:
                    print("")
                    print("Failed to launch docker container.")
                    print("Check that docker is running and that C:\\ on Windows and /tmp elsewhere is shared.")
                    sys.exit("Failed to launch docker container.")
                raise
    finally:
        if not options.shared_volumes:
            print("Extracting files from Docker container...")
            with ExecutionTimer("ExtractFiles"):
                docker_command_utilities.docker_execute_function(docker, ["cp", azureml_globals.run_id + ":/azureml-run/.", "."])

            print("Removing Docker container...")
            with ExecutionTimer("DockerRemove"):
                docker_command_utilities.docker_execute_function(docker, ["rm", azureml_globals.run_id])


if __name__ == "__main__":
    main()
