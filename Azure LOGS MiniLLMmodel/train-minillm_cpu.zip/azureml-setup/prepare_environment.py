﻿# Simple script used by Execution Service to prepare the environment.

print("")
print("")
print("Hello!")
print("Your environment is now ready.")
print("")
print("")
