﻿# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from asyncio.log import logger
import logging
import os
import sys
import json

import azureml_globals
from request_utilities import get_default_headers
import datetime
import time

try:
    # For Python 3.0 and later
    from urllib.request import urlopen, Request
    from urllib.error import URLError, HTTPError
    from urllib.parse import quote
except ImportError:
    # Fall back to Python 2's urllib2
    from urllib2 import urlopen, Request, URLError, HTTPError, quote

# Cap the logging of upload errors to the first 10.
# This ensures if there are continual failures that the log does
# not continue to grow and will finish uploading
total_request_errors = 0

_logger = logging.getLogger(__name__)

MAX_RETRIES = 3
SLEEP_DURATION = 1

def should_print_this_error():
    global total_request_errors
    max_request_errors = 10
    total_request_errors += 1
    if total_request_errors == max_request_errors:
        print("Log uploader request error limit of {} reached. ".format(max_request_errors) +
              "Further errors will not be logged in order to prevent infinite log growth.")
    return total_request_errors <= max_request_errors


def try_request_with_retries(request, max_attempts, sleep_interval_sec, wait_handle):
    for i in range(0, max_attempts):
        if i > 0:
            wait_handle.wait(sleep_interval_sec * (2 ** (i - 1)))
            if wait_handle.isSet():
                return
        try:
            urlopen(request)
            return
        except URLError as ex:
            if should_print_this_error():
                print(ex.reason)
        except HTTPError as ex:
            if should_print_this_error():
                print(ex.code)
                print(ex.read())

            if i == max_attempts - 1:
                # We don't need to wait for the Retry-After, this is the last try anyway
                continue

            # If the error had a Retry-After, respect that
            if ex.headers and ex.headers['Retry-After']:
                hdr = ex.headers['Retry-After']
                if hdr.isdigit():
                    wait_handle.wait(int(hdr))
        except Exception as ex:
            if should_print_this_error():
                print(ex)


def tail_upload_artifact(path, artifact_name, wait_handle, error=None, write_to_stdout=False):
    try:
        secondary_instance = os.environ.get(azureml_globals.env_var_secondary_instance)
        sleep_interval_sec = azureml_globals.artifact_upload_sleep_interval_sec

        if secondary_instance:
            sleep_interval_sec *= azureml_globals.artifact_upload_secondary_multiplier

        print("Streaming log file " + artifact_name)

        last_uploaded_byte = 0
        chunk_index = 0
        with open(path, 'rb') as data:
            while True:
                data.seek(last_uploaded_byte)
                read_bytes = data.read(azureml_globals.artifact_upload_chunk_size_bytes)

                if read_bytes:
                    artifacts_url = "{0}/artifact/v2.0{1}/artifacts/content/ExperimentRun/{2}".format(
                        azureml_globals.service_endpoint, azureml_globals.workspace_scope, azureml_globals.data_container_id)
                    artifacts_url += "?&path={0}&index={1}".format(artifact_name, chunk_index)

                    from run_token_provider import RunTokenProvider
                    request = Request(artifacts_url, data=read_bytes,
                                      headers=get_default_headers(RunTokenProvider.get_run_token(),
                                                                  'text/plain', read_bytes))
                    try_request_with_retries(request, azureml_globals.artifact_upload_upload_max_attempts,
                                             sleep_interval_sec, wait_handle)

                    chunk_index += 1
                    last_uploaded_byte += len(read_bytes)

                    if write_to_stdout:
                        sys.stdout.write(read_bytes.decode())

                elif wait_handle.isSet():
                    return

                wait_handle.wait(sleep_interval_sec)
    except Exception:
        if error:
            error["error"] = sys.exc_info()
        raise


def try_request(request, method=None):
    for attempt in range(MAX_RETRIES):
        try:
            if method:
                request.method = method
            return urlopen(request)
        except HTTPError as ex:
            _logger.error(f"Opening url failed with HTTP error code {ex.code}.")
            if (ex.code >= 500 or ex.code == 429) and (attempt < MAX_RETRIES - 1):
                _logger.error(f"Retrying in {SLEEP_DURATION} seconds...")
                time.sleep(SLEEP_DURATION)
            else:
                return None
        except URLError as ex:
            _logger.error(f"Opening url failed with error no {ex.errno} and reason {ex.reason}.")
            if attempt < MAX_RETRIES - 1:
                _logger.error(f"Retrying in {SLEEP_DURATION} seconds...")
                time.sleep(SLEEP_DURATION)

    return None

def upload_compute_record_artifact(payload):
    sas_url = get_SAS_url_compute_artifact()
    if sas_url is not None:
        json_data = json.dumps(payload).encode('utf8')
        request = Request(sas_url, data=json_data, headers={
            'Content-Type': 'application/octet-stream', 'x-ms-blob-type': 'BlockBlob'})
        try_request(request, method='PUT')
    else:
        _logger.error('Call to upload_compute_record_artifact got a None sas_url')

def get_SAS_url_compute_artifact():
    return get_SAS_url_for_artifact(azureml_globals.compute_record_artifact_origin,
                                    azureml_globals.compute_record_artifact_path)



def get_artifact_url_prefix(origin):
    artifact_url_prefix = "/artifact/v2.0/subscriptions/{subscription}/resourceGroups/{rg}/providers/Microsoft.MachineLearningServices/workspaces/{ws}/artifacts/{origin}/{dcid}".format(
            subscription=azureml_globals.arm_subscription,
            rg=azureml_globals.arm_resource_group,
            ws=azureml_globals.arm_workspace_name,
            origin=origin,
            dcid=azureml_globals.data_container_id)
    artifact_url_prefix = azureml_globals.service_endpoint + quote(artifact_url_prefix)
    return artifact_url_prefix

def get_SAS_url_for_artifact(origin, path):
    from run_token_provider import RunTokenProvider

    artifact_url_prefix = get_artifact_url_prefix(origin)

    create_artifact_meta_url = artifact_url_prefix + '/batch/metadata'
    create_artifact_meta_body = {"paths": [
        {
            "path": path
        }
    ]}

    create_artifact_meta_request = Request(create_artifact_meta_url,
        data=json.dumps(create_artifact_meta_body).encode('utf8'),
        headers=get_default_headers(RunTokenProvider.get_run_token(), content_type='application/json'))
    response = try_request(create_artifact_meta_request, method='POST')
    if not response:
        _logger.error('Call to create artifact metadata failed')
        return None

    print("[{}] post artifact meta request successfully.".format(datetime.datetime.now().isoformat()))

    create_artifact_meta_resp = json.loads(response.read())

    # Once metadata is created freshly, response will contain SAS url.
    if len(create_artifact_meta_resp.get('artifactContentInformation', {}).get(path, {})) > 0:
        return create_artifact_meta_resp['artifactContentInformation'][path]['contentUri']

    # If metadata was already created earlier, response will only contain errors.
    # Need to call another api to get SAS url since metadata is already created.
    if len(create_artifact_meta_resp.get('errors', {}).get(path, {})) == 0:
        _logger.error('Artifact service did not return content for SAS')
        return None

    return get_writable_SAS_url(path, origin)
    
def get_writable_SAS_url(path, origin):
    from run_token_provider import RunTokenProvider

    artifact_url_prefix = get_artifact_url_prefix(origin)

    get_SAS_url = artifact_url_prefix + '/write?path={path}'.format(path=path)
    get_SAS_url_request = Request(get_SAS_url, headers=get_default_headers(RunTokenProvider.get_run_token(), content_type='application/json'))
    response = try_request(get_SAS_url_request, method='GET')
    if not response:
        _logger.error('Call to get sas url for artifact failed, origin is {origin} artifact path is {path}')
        return None

    get_SAS_url_resp = json.loads(response.read())

    print("[{}] get artifact sas uri successfully.".format(datetime.datetime.now().isoformat())+" origin is "+origin+" artifact path is "+path)
    return get_SAS_url_resp['contentUri']