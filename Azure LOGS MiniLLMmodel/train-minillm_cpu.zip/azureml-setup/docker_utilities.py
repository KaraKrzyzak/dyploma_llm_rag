# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import errno
import json
import os
import subprocess
import sys

import constants
import error_utilities
import killable_subprocess


DOCKER_ENV_JSON_KEYS = ("imageTag", "buildImage", "dockerfilePath", "errorFilePath")

DEFAULT_ERROR_FILE_PATH = os.path.join(os.getcwd(), "environment_build_error.json")


def docker_execute_function(docker_command, command_args, print_command_args=False, *popen_args, **kwargs):
    command_args = docker_command + command_args
    return killable_subprocess.check_call(command_args, *popen_args,
                                          print_command_args=print_command_args, **kwargs)


# Checks for both docker installation, sudo-less docker configuration and returns the correct docker command.
def get_sudo_docker_command_or_error(print_nvidia_command=False):
    # TODO: change this logic once we move to the new nvidia docker runtime
    docker_command = (["docker"] if not _is_nvidia_docker_installed(print_nvidia_command) else ["nvidia-docker"])
    try:
        # we intentionally call docker images here as we need to check for insufficient permissions.
        subprocess.check_call(docker_command + ["images"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return docker_command
    except (OSError, IOError) as error:
        # if docker is not installed and on the path, we get ENOENT
        # NOTE: in python 3.3, IOError has been merged into OSError. We catch both to support python < 3.3
        if error.errno == errno.ENOENT:
            _docker_error(error)
        else:
            print(repr(error))
            _write_error_and_exit(error.strerror)
    except subprocess.CalledProcessError as error:
        # we get a non-zero exit status if sudoless docker hasn't been configured.
        # checking whether we can run sudo docker needs to be done only on linux based targets
        if not sys.platform.startswith("linux"):
            _docker_error(error)
        try:
            subprocess.check_call(["sudo"] + docker_command + ["images"],
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return ["sudo"] + docker_command
        except (subprocess.CalledProcessError, OSError, IOError) as error:
            _sudo_error(error)


def check_image_existence(env_file_path):
    docker_command = get_sudo_docker_command_or_error()

    docker_env_details = _get_docker_env_details_from_json_or_error(env_file_path)
    image_tag = docker_env_details["imageTag"]

    return _docker_inspect(docker_command, image_tag)


def materialize_image_or_error(env_file_path):
    docker_command = get_sudo_docker_command_or_error()

    docker_env_details = _get_docker_env_details_from_json_or_error(env_file_path)
    image_tag = docker_env_details["imageTag"]
    build_image = docker_env_details["buildImage"]
    dockerfile_path = docker_env_details["dockerfilePath"]
    error_file_path = os.path.join(os.getcwd(), docker_env_details["errorFilePath"])

    if build_image:
        _docker_build_or_error(docker_command, dockerfile_path, [image_tag], error_file_path)
    else:
        # We should directly pull the base image if an image build is not needed.
        _docker_pull_or_error(docker_command, image_tag, error_file_path)


def push_image_to_workspace_acr(env_file_path, acr_address):
    docker_command = get_sudo_docker_command_or_error()
    docker_env_details = _get_docker_env_details_from_json_or_error(env_file_path)
    image_tag = docker_env_details["imageTag"]

    # Tag image tag to point to a location in acr
    workspace_acr_image_tag = acr_address + "/" + image_tag
    tag_command = ["tag", image_tag, workspace_acr_image_tag]
    docker_execute_function(docker_command, tag_command)

    push_command = ["push", workspace_acr_image_tag]
    docker_execute_function(docker_command, push_command)

    # Clean up locally cached images
    cleanup_local_image_cache(docker_command, image_tag)


def cleanup_local_image_cache(docker_command, image_tag):
    # Start by retrieving the imageid for the specific image tag. These should be shared
    # across all tags for a single image
    image_id = _retrieve_docker_image_id(docker_command, image_tag)
    if image_id is not None:
        print("Deleting {} from local machine".format(image_tag))
        _delete_docker_image(docker_command, image_id)


# Logs in to a Docker registry using the provided credentials and address.
def docker_login(docker_command, docker_image_username, docker_image_password, docker_image_address=None):
    login_command = ["login", "-u", docker_image_username, "-p", docker_image_password]
    if docker_image_address:
        login_command.append(docker_image_address)

    docker_execute_function(docker_command, login_command)


def docker_logout(docker_command):
    docker_execute_function(docker_command, ["logout"])


# Retrieves the imageid for a given image tag
def _retrieve_docker_image_id(docker_command, image_tag):
    image_id_command = docker_command + ["images", "-q", image_tag.rstrip()]
    image_id = subprocess.check_output(image_id_command, stderr=subprocess.STDOUT,
                                       encoding='utf-8', errors='ignore').rstrip()
    return image_id


# Deletes images for a particular imageId locally
def _delete_docker_image(docker_command, image_id):
    # Delete both image_tag and workspace_image_tag locally
    delete_command = ["rmi", "-f", image_id]
    docker_execute_function(docker_command, delete_command)


# Pulls a docker image using the provided docker command and image tag.
def _docker_pull_or_error(docker_command, image_tag, error_file_path):
    pull_command = ["pull", image_tag]
    try:
        docker_execute_function(docker_command, pull_command, print_command_args=True)
    except subprocess.CalledProcessError as ex:
        print(repr(ex))
        error_msg = constants.docker_pull_error.format(image_tag=image_tag)
        _write_error_and_exit(error_msg, error_file_path=error_file_path)


# Builds a docker image using the current path '.'
def _docker_build_or_error(docker_command, dockerfile_path, image_tags, error_file_path, path = "."):
    build_command = ["build", "-f", dockerfile_path, path]
    for tag in image_tags:
        build_command.extend(["-t", tag])
    try:
        docker_execute_function(docker_command, build_command, print_command_args=True)
    except subprocess.CalledProcessError as ex:
        print(repr(ex))
        error_msg = constants.docker_build_error.format(exit_code=ex.returncode)
        _write_error_and_exit(error_msg, error_file_path=error_file_path)


def _get_docker_env_details_from_json_or_error(env_file_path):
    with open(env_file_path) as env_file:
        env_details = json.load(env_file)
        if "dockerEnvironment" in env_details:
            docker_env_details = env_details["dockerEnvironment"]
            if all([k in docker_env_details for k in DOCKER_ENV_JSON_KEYS]):
                return docker_env_details
            else:
                error_msg = constants.env_file_missing_key_error.format(
                    env_file_path=env_file_path, env_type="docker", env_file_keys=DOCKER_ENV_JSON_KEYS)
                _write_error_and_exit(error_msg)
        else:
            error_msg = constants.env_file_missing_details_error.format(
                env_type="docker", env_file_path=env_file_path)
            _write_error_and_exit(error_msg)


# Inspects the Docker object via docker inspect using the image tag provided.
# NOTE: We use the return code from the subprocess to determine whether the image has been materialized.
def _docker_inspect(docker_command, image_tag):
    # Hide output from this inspection because it's not interesting for diagnostics
    # and will show an error in expected situations, which confuses log readers.
    # TODO: We do not use docker_execute_function, because we do not want its built in exception handling.
    #       We should eventually build a way to call it with more flexible error handling.
    return_code = subprocess.call(docker_command + ["inspect", image_tag],
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print("")
    if return_code == 0:
        print("Found materialized image on target: {}".format(image_tag))
    else:
        print("Materialized image not found on target: {}".format(image_tag))
    return return_code == 0


# Checks whether nvidia-docker is installed
def _is_nvidia_docker_installed(print_nvidia_command):
    try:
        subprocess.check_call(["nvidia-docker"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if print_nvidia_command:
            print("nvidia-docker is installed on the target. Using nvidia-docker for docker operations.")
        return True
    except (OSError, IOError):
        # NOTE: in python 3.3, IOError has been merged into OSError. We catch both to support python < 3.3
        return False
    except subprocess.CalledProcessError:
        # To be safe, we'll assume that nvidia-docker is not installed/configured for other failures.
        return False


def _write_error_and_exit(error_msg, error_file_path=None):
    print()
    print(error_msg)
    print()
    error_response = error_utilities.get_error_response_dict(error_msg)

    error_file_path = DEFAULT_ERROR_FILE_PATH if error_file_path is None else error_file_path
    with open(error_file_path, "w") as error_file:
        json.dump(error_response, error_file, indent=4)
    sys.exit(1)


def _docker_error(error=None):
    if error:
        print(repr(error))
    _write_error_and_exit(constants.docker_not_installed_error)


def _sudo_error(error=None):
    if error:
        print(repr(error))
    _write_error_and_exit(constants.docker_sudo_error)
