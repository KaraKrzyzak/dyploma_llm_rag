﻿# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import os
import json

def _get_rank():
    value = os.environ.get("OMPI_COMM_WORLD_RANK")
    if value is None:
        value = os.environ.get("PMI_RANK")
    if value is None:
        value = os.environ.get("RANK")
    if value is None:
        value = os.environ.get("NODE_RANK")
    try:
        return int(value)
    except:
        return None

def _get_world_size():
    value = os.environ.get("OMPI_COMM_WORLD_SIZE")
    if value is None:
        value = os.environ.get("PMI_SIZE")
    if value is None:
        value = os.environ.get("WORLD_SIZE")
    if value is None:
        value = os.environ.get("NODE_COUNT")
    try:
        return int(value)
    except:
        return None

def _is_ps_job():
    return os.environ.get("PARAMETER_SERVER_JOB")

def _is_pytorch_job():
    return os.environ.get("AZUREML_PYTORCH_JOB")
    
def configure_distributed_settings():
    target_type = os.environ.get("AZUREML_TARGET_TYPE")
    if not target_type or (target_type.lower() != "batchai" and target_type.lower() != "aisc"):
        return
    # Since we are appending the task name and id to the log names
    # we need to make sure we do it only once.
    distrib_configured = os.environ.get("AZUREML_DISTRIB_CONFIGURED")
    if distrib_configured:
        return
    psjob = _is_ps_job()
    pytorchjob = _is_pytorch_job()
    # rank (and world_size) is used for both MPI and PyTorch jobs
    rank = _get_rank()
    ps_jobname = ""
    ps_taskindex = ""
    control_log_path = os.environ.get("AZUREML_CONTROLLOG_PATH")
    driver_log_path = os.path.expandvars(os.environ.get("AZUREML_DRIVERLOG_PATH"))
    control_log_str = control_log_path.replace("control_log", "control_log_{}_{}")
    driver_log_str = driver_log_path.replace("driver_log", "driver_log_{}_{}")

    if psjob:
        tf_config = os.environ.get("TF_CONFIG")
        if not tf_config:
            message = "TF_CONFIG env variable (defined by Batch AI for parameter server jobs) is not found or empty."
            raise Exception(message)
        tf_config_json = json.loads(tf_config)
        print("TF_CONFIG:\n" + json.dumps(tf_config_json, indent=4))
        ps_jobname = tf_config_json.get('task', {}).get('type')
        ps_jobname  = "worker" if ps_jobname  == "master" else ps_jobname 
        ps_taskindex = tf_config_json.get('task', {}).get('index')

        if ps_taskindex == 0 and ps_jobname  == "worker":
            cluster = tf_config_json.get('cluster')
            ps_spec = cluster.get('ps', {})
            worker_spec = cluster.get('worker', {})
            distrib_log_list = [control_log_str.format("ps", i) for i in range(len(ps_spec))]
            distrib_log_list += [driver_log_str.format("ps", i) for i in range(len(ps_spec))]
            distrib_log_list += [control_log_str.format("worker", i) for i in range(len(worker_spec))]
            distrib_log_list += [driver_log_str.format("worker", i) for i in range(len(worker_spec))]
            os.environ["AZUREML_DISTRIB_LOGS"] = ",".join(distrib_log_list)


    # Non distributed: primary = true
    # Distributed (MPI, PyTorch or TensorFlow): need a single primary instance.
    # For MPI/PyTorch it's rank 0. For TensorFlow, it's worker 0.
    distributed_job = rank is not None or psjob
    primary_instance = (not distributed_job) or (rank == 0) or (ps_taskindex == 0 and ps_jobname  == "worker")

    # The log-naming for this process needs to match the log-naming used to construct distrib_log_list
    rank_text = "main"
    if distributed_job:
        if rank is not None:
            rank_text = "rank_{}".format(rank)
        else:  # psjob
            rank_text = "{}_{}".format(ps_jobname , str(ps_taskindex))

        # When running a distributed job, mangle our log filenames so we can put them side by side.
        # That way the user can easily see all of their control logs together.
        control_log_path = control_log_path.replace("control_log", "control_log_{}".format(rank_text))
        driver_log_path = driver_log_path.replace("driver_log", "driver_log_{}".format(rank_text))
        os.environ["AZUREML_DRIVERLOG_PATH"] = driver_log_path
        os.environ["AZUREML_CONTROLLOG_PATH"] = control_log_path
        if not primary_instance:
            os.environ["AZUREML_SECONDARY_INSTANCE"] = "True"

        if rank == 0:
            world_size = _get_world_size()
            if world_size:
                distrib_log_list = [control_log_str.format("rank", i) for i in range(world_size)]
                distrib_log_list += [driver_log_str.format("rank", i) for i in range(world_size)]
                os.environ["AZUREML_DISTRIB_LOGS"] = ",".join(distrib_log_list)
    if psjob:
        print("This is a TensorFlow job. Job Name:{} Task index:{}.".format(ps_jobname, str(ps_taskindex)))
    elif rank is not None:
        if pytorchjob:
            print("This is a PyTorch job. Rank:{}".format(rank))
        else:
            print("This is an MPI job. Rank:{}".format(rank))
    os.environ["AZUREML_PROCESS_NAME"] = rank_text
    os.environ["AZUREML_DISTRIB_CONFIGURED"] = "true"