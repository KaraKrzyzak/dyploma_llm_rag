from __future__ import print_function

import datetime
# log as early as possible to get a more accurate time of start.
print("[{}] Entering context manager injector.".format(datetime.datetime.utcnow().isoformat()))

import glob
import argparse
import os
import runpy
import sys
import logging
import json
import base64
import traceback

if sys.version_info.major != 3 or sys.version_info.minor < 5:
    raise RuntimeError("Python version " + str(sys.version_info) + " is not supported. Please use python>=3.5")


sys.path.append(os.path.dirname(__file__))
from _vendor_contextlib2 import ExitStack
from _tracer import get_tracer
import azureml_globals

# For debugging purposes
# logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.INFO)

module_logger = logging.getLogger(__name__)
_tracer = get_tracer(__name__)

is_hdi = os.environ.get("AZUREML_TARGET_TYPE") == "cluster"
TRACEPARENT = "AZUREML_SDK_TRACEPARENT"


if not is_hdi:
    from context_managers import TrackError

IsAzureMLSdkAvailable = True
try:
    from azureml.exceptions import AzureMLException

    class UserScriptException(AzureMLException):

        _error_code = "UserError"

        def __init__(self, inner_exception):
            super(UserScriptException, self).__init__(inner_exception.message, inner_exception, inner_exception._target, inner_exception._details, inner_exception._message_format, inner_exception._message_parameters, inner_exception._reference_code)

except ImportError:
    IsAzureMLSdkAvailable = False


class LocalUserScriptException(Exception):
    DEFAULT_ERROR_MESSAGE = "Local execution of User Script failed."

    def __init__(self, message=DEFAULT_ERROR_MESSAGE):
        self.message = message

        super().__init__(self.message)


class dummy():
    def __enter__(self):
        return None

    def __exit__(self, exc_type, exc_value, traceback):
        pass


class ContextManagerWrapper(object):
    def __init__(self, context_manager, name):
        self.context_manager = context_manager
        self.name = name

    def __enter__(self):
        with TrackError(error_message_prefix=self.name + " initialization failed: ", check_user_error_by_type=True) if not is_hdi else dummy():
            module_logger.info("Entering context: " + self.name)
            self.context_manager.__enter__()

    def __exit__(self, *exc_details):
        with TrackError(error_message_prefix=self.name + " finalization failed: ", check_user_error_by_type=True) if not is_hdi else dummy():
            module_logger.info("Exiting context: " + self.name)
            self.context_manager.__exit__(*exc_details)


def get_class(kls):
    """
    get class from fully qualified name with security validation
    Returns the class type that can be instantiated safely
    """
    # Import the context_managers module to access the classes
    import context_managers

    # Security fix: Map allowed class names to actual class objects
    # This serves as both validation and lookup
    class_mapping = {
        'context_managers.ProjectPythonPath':
            context_managers.ProjectPythonPath,
        'context_managers.FidelityLogUpload':
            context_managers.FidelityLogUpload,
        'context_managers.TrackUserError':
            context_managers.TrackUserError,
        'context_managers.RunHistory':
            context_managers.RunHistory,
        'context_managers.Datasets':
            context_managers.Datasets,
        'context_managers.DataStores':
            context_managers.DataStores,
        'context_managers.ParallelRunBackend':
            context_managers.ParallelRunBackend,
        'context_managers.UserExceptions':
            context_managers.UserExceptions
    }

    # Find the matching class based on suffix and return it
    for allowed_class_name, class_obj in class_mapping.items():
        if kls.endswith(allowed_class_name):
            module_logger.info(f"Found matching class '{kls}' for allowed class '{allowed_class_name}'")
            return class_obj

    module_logger.error(f"Invalid class '{kls}' - must end with one of the allowed class names: {list(class_mapping.keys())}")
    print(f"[Error]: Invalid class '{kls}' - must end with one of the allowed class names: {list(class_mapping.keys())}")

    raise ValueError(f"Invalid class '{kls}' - must end with one of the allowed class names: "
                     f"{list(class_mapping.keys())}")


def execute_with_context(wrapped_context_managers, invocation):
    scriptType = os.environ.get("AZUREML_SCRIPTTYPE")
    print("Script type = {}".format(scriptType))
    isCommand = scriptType == "COMMAND"
    isMPIRun = ("OMPI_COMM_WORLD_RANK" in os.environ) or ("PMI_RANK" in os.environ)

    if isCommand == True:
        # there is no need to parse the command to create individual parameters because :
        # - os.path.expandvars() iterates through all tokens with format $env or ${env} passed
        # - Dataset process_arguments() method replaces all occurrences
        # Also, the command is shell dependent making parsing difficult
        print("[{}] Command={}".format(datetime.datetime.utcnow().isoformat(), invocation[0]))
        invocation = [invocation[0]]


    primary_instance = not os.environ.get("AZUREML_SECONDARY_INSTANCE")
    with ExitStack() as stack:
        with _tracer.start_as_current_span('execute_with_context.enter', user_facing_name='Setting up run'):
            # Enter contexts
            for wrapper in wrapped_context_managers:
                # Check if the context manager specified that it should only run on a single instance
                single_instance = getattr(wrapper.context_manager, "single_instance", False)

                if primary_instance or not single_instance:
                    wrapper_span_name = 'execute_with_context.enter.' + wrapper.name
                    with _tracer.start_as_current_span(wrapper_span_name + '.process_arguments'):
                        try:
                            wrapper.context_manager.process_arguments(invocation)
                        except AttributeError:
                            pass
                    with _tracer.start_as_current_span(wrapper_span_name, user_facing_name='Entering cm ' + wrapper.name):
                        stack.enter_context(wrapper)

        # Run the user script
        osIndicator = "Windows" if os.name == "nt" else "Linux"
        invocation = invocation[0].split() if osIndicator == "Windows" and isCommand and "**" in invocation[0] else invocation
        expand_invocation = []
        
        for item in invocation:
            item = os.path.expandvars(item)

            # if os is windows & the input path name end with '**' & the folder contains only one file, append file name to path
            if osIndicator == "Windows" and item.endswith("**"):
                contents_in_dir = glob.glob(item)
                if len(contents_in_dir) == 1 and os.path.isfile(contents_in_dir[0]):
                    item = contents_in_dir[0]

            expand_invocation.append(item)

        if len(invocation) > 0 and isCommand == False:
            # Output script name and arguments to assist user with debugging
            # Command logs a similar line below, so avoid logging this information multiple times
            print("[{}] Current directory: {}".format(datetime.datetime.utcnow().isoformat(), os.getcwd()))
            print("[{}] Preparing to call script [{}] with arguments:{}".format(datetime.datetime.utcnow().isoformat(), invocation[0],  invocation[1:]))
            print("[{}] After variable expansion, calling script [{}] with arguments:{}".format(datetime.datetime.utcnow().isoformat(), expand_invocation[0], expand_invocation[1:]))
            print()

        if isCommand == False:
            sys.argv = expand_invocation
        module_logger.debug("Executing script inside contexts: " + sys.argv[0])
        # Flush to get logging up to this point written to logs before logging from subprocess
        sys.stdout.flush()
        sys.stderr.flush()

        completion_message = "The experiment completed successfully."
        exceptionFromUserScript = False

        # variables used to ensure ES scripts are not affected by user script
        setup_modules = []
        user_script_dir = ""
        restorePerformed = False

        try:
            with _tracer.start_as_current_span('execute_with_context.user_script', user_facing_name='Executing run') as span:

                # We strip the azureml-setup/context_manager_injector.py and runpy.py layers from the stack at the end of this file
                # The strip occurs by traversing the stack in reverse order and stopping once the innermost runpy frame is hit
                # This frame calls exec(code, run_globals). If this were to ever change the stripping logic will have to be updated
                # The bad_import.py test is modified to catch this behavior.

                try:
                    traceparent = span.to_w3c_traceparent()
                except AttributeError:
                    traceparent = None

                # this should be called after all ES\SDK code has been invoked
                setup_modules, user_script_dir = prepareToRunUserScript(isCommand)

                if isCommand == True:
                    currentFolder = os.getcwd()
                    env_copy = os.environ.copy()
                    if traceparent:
                        env_copy[TRACEPARENT] = traceparent

                    commandString = ' '.join(expand_invocation)
                    print("[{}] Command Working Directory={}".format(datetime.datetime.utcnow().isoformat(), currentFolder))
                    print("[{}] Starting {} command : {}".format(datetime.datetime.utcnow().isoformat(), osIndicator, commandString))

                    exceptionFromUserScript = True

                    # MPI fails to start when subprocess.Popen is used
                    if isMPIRun:
                        exitCode = os.system(commandString)

                        # exitCode is the actual exit code in Windows
                        # it has to be interpreted in Linux based on how the process terminated
                        returnCode = exitCode
                        processTerminatedNormally = True
                        if osIndicator == "Linux":
                            if os.WIFEXITED(exitCode) == True:
                                returnCode = os.WEXITSTATUS(exitCode)
                            else:
                                processTerminatedNormally = False

                        if processTerminatedNormally == True:
                            print("[{}] Command finished with exit code {} interpreted as return code {}".format(datetime.datetime.utcnow().isoformat(), exitCode, returnCode))
                        else:
                            print("[{}] Command was not terminated normally ( using exit(), _exit() or returning from main() ) with exit code {}".format(datetime.datetime.utcnow().isoformat(), exitCode))

                        process_return_code(returnCode)
                    else:
                        import subprocess

                        command = subprocess.Popen(commandString, bufsize=-1, cwd=currentFolder, env=env_copy, shell=True)

                        # wait for the process to finish - this will block until process exists
                        stdout, stderr = command.communicate()

                        # return code is unsigned int in Python - if the result code is negative then it will be interpreted as unsigned int
                        import ctypes
                        signedReturnCode = ctypes.c_int32(command.returncode).value
                        print("[{}] Command finished with return code {}".format(datetime.datetime.utcnow().isoformat(), signedReturnCode))

                        stdout, stderr

                        process_return_code(signedReturnCode)

                    exceptionFromUserScript = False
                else:
                    if traceparent:
                        os.environ[TRACEPARENT] = traceparent
                    exceptionFromUserScript = True
                    runpy.run_path(sys.argv[0], globals(), run_name="__main__")
                    exceptionFromUserScript = False

                restoreAfterUserScript(isCommand, setup_modules, user_script_dir)
                restorePerformed = True

        except SystemExit as ex:
            # Handle valid exit.  Raise exception for non-zero return code.
            # TODO: Need to find out what caused the stack trace is printed
            if ex.code is not None and ex.code != 0:
                completion_message = "The experiment failed with exit code: {}.".format(ex.code)
                raise
        except BaseException as baseEx:
            completion_message = "The experiment failed."

            restoreAfterUserScript(isCommand, setup_modules, user_script_dir)
            restorePerformed = True

            if exceptionFromUserScript == True and os.environ.get("AZUREML_LOCALRUN", "false") == "true":
                # local run (conda or docker) starts control_script_common.py as a process, which runs context_manager_injector.py as separate process, too
                # the error is reported from control_script_common.py, so we need to use exit codes to identify an user error
                raise LocalUserScriptException()

            # If the user script throws an AzureMLException then it is considered to be an user error.
            # Any exception not derived from AzureMLException is already handled as an user error - see the code in run_history_facade.py , method _error_details_to_dictionary
            if exceptionFromUserScript == True and IsAzureMLSdkAvailable == True:
                # AzureMLException might not be available in user managed environments, so checking for AzureMLException type is done on a separate if
                if isinstance(baseEx, AzureMLException):
                    exceptionInfo = sys.exc_info()
                    raise UserScriptException(baseEx).with_traceback(exceptionInfo[2])

            raise
        finally:
            if restorePerformed == False:
                restoreAfterUserScript(isCommand, setup_modules, user_script_dir)
                restorePerformed = True

            with _tracer.start_as_current_span('execute_with_context.finalize', user_facing_name='Finalizing run'):
                # To indicate to a user that the user related command has
                # completed, and now some post-processing steps will happen.
                print("\n")
                print("[{}] {} Finalizing run...".format(datetime.datetime.utcnow().isoformat(), completion_message))
                # TODO: This is broken on worker nodes, so disabling for hdi.
                # Disabling for distributed runs as it's broken there too
                if azureml_globals.target_type != azureml_globals.batchai_target_type and not azureml_globals.is_hdi:
                    print("[{}] Start FinalizingInRunHistory".format(datetime.datetime.utcnow().isoformat()))
                    try:
                        from log_history_status import log_finalizing
                        log_finalizing(caller="context_manager_injector")
                    except Exception as ex:
                        print("Error occurred when setting run status to Finalizing: {}".format(ex))

# remove setup related modules from sys.modules so that user can import any modules from user directory
def prepareToRunUserScript(isCommand):
    setup_modules = []

    if isCommand == True:
        return setup_modules, ""

    for module_name in list(sys.modules):
        if 'azureml-setup' in str(sys.modules[module_name]):
            setup_modules.append(module_name)
    for module_name in setup_modules:
        try:
            del sys.modules[module_name]
        except KeyError as ke:
            pass

    # add user script directory to the top of sys.path for user module imports
    user_script_dir = os.path.dirname(sys.argv[0])
    sys.path.insert(0, user_script_dir)

    return setup_modules, user_script_dir

def restoreAfterUserScript(isCommand, setup_modules, user_script_dir):
    if isCommand == True:
        return

    # remove user script directory from the top of the sys.path
    sys.path.remove(user_script_dir)

    # replace any user modules imported to setup related modules
    user_updated_modules = []
    for module_name in setup_modules:
        if sys.modules.get(module_name) is not None:
            user_updated_modules.append(module_name)
    import importlib
    for module_name in user_updated_modules:
        imported_module = importlib.import_module(module_name)
        try:
            importlib.reload(imported_module)
        except Exception as ex:
            print("[{}] Reloading {} failed: {}.".format(datetime.datetime.utcnow().isoformat(), imported_module, ex))

def process_return_code(returnCode):

    # zero succeeds always
    if returnCode == 0:
        return

    successCodeCondition = os.environ.get("AZUREML_RETURN_CODE_CONDITION")

    if successCodeCondition == "ZeroOrGreater" and returnCode >= 0:
        return

    # if the flow gets here then it is due to a possible failure
    # check if the failure can be ignored based on additional success codes

    additionalSuccessCodes = os.environ.get("AZUREML_ADDITIONAL_SUCCESSFUL_RETURN_CODES")
    if additionalSuccessCodes == None:
        sys.exit(returnCode)

    successCodes = [i for i in additionalSuccessCodes.split(',')]
    if str(returnCode) not in successCodes:
        sys.exit(returnCode)

def create_wrapped_context_manager(pair):
    """
    attempt to import context manager type
    create context manager with its config
    and wrap it so that we can log enter and exit
    """

    cm_name, cm_type = pair.split(":")

    config_key = "AZUREML_CONTEXT_MANAGER_" + cm_name.upper()
    cm_config = os.environ.get(config_key)
    if cm_config:
        # Note: we have to base64 decode the environment variable that was
        # encoded by the service in order to escape double quotes
        cm_config = base64.b64decode(cm_config)
        # json.loads only accepts bytes-like inputs in Python 3.6+
        # As we support 3.5.2+, decode to str before deserializing to JSON
        # We know the encoding is UTF-8 from InjectedContextConfiguration
        cm_config = cm_config.decode('utf-8')
        cm_config = json.loads(cm_config)

    # make class
    module_logger.debug("Importing context manager module for {0}".format(cm_name))
    cm_class = get_class(cm_type)

    # make object
    module_logger.debug("Constructing context manager object of type {0}".format(cm_class))
    context_manager = cm_class(cm_config)

    return ContextManagerWrapper(context_manager, cm_name)


def strip_stack_of_azureml_layers(exc_type, exc_val, exc_traceback):
    """
        The actual traceback that gets printed when the exception is in the user code is:

        Traceback (most recent call last):
            File "azureml-setup/context_manager_injector.py", line 161, in <module>
                execute_with_context(cm_objects, options.invocation)
            File "azureml-setup/context_manager_injector.py", line 91, in execute_with_context
                runpy.run_path(sys.argv[0], globals(), run_name="__main__")
            File "<USERPROFILE>\AppData\Local\Continuum\Miniconda3\envs\cli_dev\lib\runpy.py", line 263, in run_path
                pkg_name=pkg_name, script_name=fname)
            File "<USERPROFILE>\AppData\Local\Continuum\Miniconda3\envs\cli_dev\lib\runpy.py", line 96, in _run_module_code
                mod_name, mod_spec, pkg_name, script_name)
            File "<USERPROFILE>\AppData\Local\Continuum\Miniconda3\envs\cli_dev\lib\runpy.py", line 85, in _run_code
                exec(code, run_globals)
            File "bad_import.py", line 5, in <module>
                import thisdoesnotexist
        ModuleNotFoundError: No module named 'thisdoesnotexist'

        however we strip the first 5 layers to give the user a traceback that only contains the user code as part of it
    """
    traceback_as_list = traceback.format_exception(exc_type, exc_val, exc_traceback)
    reversed_traceback_list = reversed(traceback_as_list)
    reversed_trimmed_stack = []
    # currently the innermost runpy stack occurs inside runpy.py in _run_code and inside the exec(code, run_globals) function
    # if that changes then the regular stack will be printed
    keywords_in_innermost_runpy_stack_frame = ["runpy.py", "_run_code", "exec(code, run_globals)"]
    error_is_in_user_code = False
    for stack_frame in reversed_traceback_list:
        if all([keyword in stack_frame for keyword in keywords_in_innermost_runpy_stack_frame]):
            error_is_in_user_code = True
            break
        reversed_trimmed_stack.append(stack_frame)
    if error_is_in_user_code:
        # Find the first index of "Traceback (most recent call last):" in reversed list and append the cause exceptions
        # This will handle users using 'from with raise' when raising exception
        reversed_traceback_as_list = traceback_as_list[::-1]
        traceback_indexes = [idx for idx,stack_frame in enumerate(reversed_traceback_as_list)
                             if "Traceback (most recent call last):" in stack_frame]
        if len(traceback_indexes) > 0:
            reversed_trimmed_stack.extend(reversed_traceback_as_list[traceback_indexes[0]:])

    trimmed_stack = list(reversed(reversed_trimmed_stack))
    print("".join(trimmed_stack))


if __name__ == '__main__':
    argument_parser = argparse.ArgumentParser()
    argument_parser.add_argument('-i', '--inject', action='append', default=[])
    argument_parser.add_argument("invocation", nargs=argparse.REMAINDER)
    options = argument_parser.parse_args()

    print("[{}] {} Command line Options: {}".format(datetime.datetime.utcnow().isoformat(), os.path.basename(__file__), options))

    # need to do this to set secondary instances for backward compat with
    # older versions of azureml-defaults
    from distributed_settings import configure_distributed_settings
    configure_distributed_settings()

    cm_objects = [create_wrapped_context_manager(pair) for pair in options.inject]
    try:
        execute_with_context(cm_objects, options.invocation)
        print("[{}] Finished context manager injector.".format(datetime.datetime.utcnow().isoformat()))
    except SystemExit as ex:
        exc_type, exc_val, exc_traceback = sys.exc_info()
        strip_stack_of_azureml_layers(exc_type, exc_val, exc_traceback)
        print("[{}] Finished context manager injector with SystemExit exception.".format(datetime.datetime.utcnow().isoformat()))
        if ex.code is not None:
            sys.exit(ex.code)
        else:
            sys.exit(1)
    except Exception as ex:
        exc_type, exc_val, exc_traceback = sys.exc_info()
        strip_stack_of_azureml_layers(exc_type, exc_val, exc_traceback)
        print("[{}] Finished context manager injector with Exception.".format(datetime.datetime.utcnow().isoformat()))
        if isinstance(ex, LocalUserScriptException):
            sys.exit(255)
        else:
            sys.exit(1)
