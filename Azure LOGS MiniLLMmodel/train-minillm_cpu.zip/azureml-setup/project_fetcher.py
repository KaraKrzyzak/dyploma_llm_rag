﻿# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from __future__ import print_function
from execution_timer import ExecutionTimer

import errno
import json
import os
import time
import zipfile
import datetime
import subprocess
import tempfile
import shutil
import platform

import azureml_globals
from request_utilities import get_default_headers
from utility_context_managers import TimeoutHandler

# http timeouts
env_var_urlopen_timeout = 'AZUREML_URLOPEN_TIMEOUT_SEC'
urlopen_timeout_sec = int(os.getenv(env_var_urlopen_timeout, "60"))
# read timeout needs to be lower than job preparation timeout job_prep_timeout_sec
env_var_httpread_timeout = 'AZUREML_HTTPREAD_TIMEOUT_SEC'
httpread_timeout_sec = int(os.getenv(env_var_httpread_timeout, "3000"))

try:
    # For Python 3.0 and later
    from urllib.request import urlopen, urlretrieve, Request
    from urllib.parse import quote
    print("[{}] Using urllib.request Python 3.0 or later".format(datetime.datetime.utcnow().isoformat()))
except ImportError:
    # Fall back to Python 2's urllib2
    from urllib2 import urlopen, Request
    from urllib import urlretrieve, quote
    print("[{}] Using urllib.request Python 2".format(datetime.datetime.utcnow().isoformat()))


def try_request_with_retries(request, max_attempts, time_between_retries):
    for i in range(0, max_attempts):
        try:
            return request()
        except Exception as ex:
            print("[{}] download failed with {}, retry {} times.".format(
                datetime.datetime.utcnow().isoformat(), ex, i))
            if i < max_attempts - 1:
                time.sleep((i + 1) * time_between_retries)
                continue
            else:
                raise


def fetch_project_zip(uri):
    print("Retrieving project from URI: " + uri)

    zip_path = "azureml-setup/project.zip"
    try_request_with_retries(lambda: urlretrieve(uri, zip_path), max_attempts=10, time_between_retries=.5)

    with zipfile.ZipFile(zip_path, "r") as archive:
        archive.extractall(".")


def fetch_project_snapshot(snapshot_id, path_stack=["."], snapshotEntityId=None):
    """
    Fetches and downloads snapshot to the directory provided by path_stack.
    Parameters
    ----------
    snapshot_id: str
    path_stack: list
    snapshotEntityId: str

    Returns
    -------

    """
    if azureml_globals.git_integration_enabled:
        _fetch_snapshot_new_implementation(snapshot_id, path_stack, snapshotEntityId)
    else:
        # Same behavior as old code, keeping FOOF until new behavior stablizes.
        _fetch_local_files_based_snapshot(snapshot_id, path_stack, snapshotEntityId)


def fetch_project_snapshot_sas_tree_from_snapshot_id(snapshot_id):
    """
    Fetches snapshot sas tree object using snapshot id
    Parameters
    ----------
    snapshot_id: str

    Returns
    -------
    dict
    """
    return _fetch_project_snapshot_sas_tree_from_snapshot_id(snapshot_id, None)


def get_snapshot_metadata(snapshot_id):
    """

    Parameters
    ----------
    snapshot_id: str

    Returns
    -------
    dict
    """

    return _get_snapshot_metadata(snapshot_id)


def download_snapshot_single_file(full_path, sas_url):
    """
    Download a single file from snapshot service

    Parameters
    ----------
    full_path: str
    sas_url: str

    Returns
    -------

    """
    try:
        try_request_with_retries(lambda: _download_sas_to_file(full_path, sas_url, "ReadSnapshotFile"), max_attempts=10, time_between_retries=1)
    except Exception as ex:
        print("")
        print("[{date}]Unable to download project file with filename {filename} ".format(date=datetime.datetime.utcnow().isoformat(), filename=full_path))
        raise ex


def _fetch_snapshot_new_implementation(snapshot_id, path_stack, snapshot_entity_id):
    """

    Parameters
    ----------
    snapshot_id: str
    path_stack: list
    snapshot_entity_id: str

    Returns
    -------

    """
    snapshot_metadata = _get_snapshot_metadata(snapshot_id)

    snapshot_type = _get_snapshot_type(snapshot_metadata)
    if snapshot_type == "LocalFiles":
        _fetch_local_files_based_snapshot(snapshot_id, path_stack, snapshot_entity_id)
    elif snapshot_type == "Git":
        _check_if_git_installed()
        _clone_and_checkout_git_repo(snapshot_metadata, path_stack)
    else:
        raise ValueError("Unsupported snapshot type returned from service {}".format(snapshot_type))


def _fetch_local_files_based_snapshot(snapshot_id, path_stack, snapshot_entity_id):
    """
    Fetches and downloads local file based snapshot.
    This is also the old implementation before git based snapshots were also added.
    Parameters
    ----------
    snapshot_id: str
    path_stack: list
    snapshot_entity_id: str

    Returns
    -------

    """
    sas_tree = _fetch_project_snapshot_sas_tree_from_snapshot_id(snapshot_id, snapshot_entity_id)

    with ExecutionTimer("DownloadProjectFromSasUrls"):
        _download_tree(sas_tree, path_stack)


def _fetch_project_snapshot_sas_tree_from_snapshot_id(snapshot_id, snapshot_entity_id):
    """
    Fetches snapshot sas tree object using snapshot id
    Parameters
    ----------
    snapshot_id: str
    snapshot_entity_id: str

    Returns
    -------
    dict
    """

    data = None
    if snapshot_entity_id:
        print("[{}] Retrieving project from snapshotEntityId: {}".format(datetime.datetime.utcnow().isoformat(),
                                                                         snapshot_entity_id))
        project_service_url = "{0}/content/v1.0/{1}/sas".format(azureml_globals.service_endpoint,
                                                                _parse_entity_id(snapshot_entity_id))
    # TODO: Remove the old code path for workspace snapshot id (guid style), v2 API actually could handle both.
    elif not snapshot_id.startswith('azureml://'):
        project_service_url = "{0}/content/v1.0/subscriptions/{1}/resourceGroups/{2}"\
                        "/providers/Microsoft.MachineLearningServices/"\
                        "workspaces/{3}/snapshots/{4}/sas".format(azureml_globals.service_endpoint,
                                                                azureml_globals.arm_subscription,
                                                                quote(azureml_globals.arm_resource_group, safe=''),
                                                                azureml_globals.arm_workspace_name,
                                                                snapshot_id)
    else:
        print("[{}] Retrieving project from snapshot: {}".format(datetime.datetime.utcnow().isoformat(), snapshot_id))
        project_service_url = "{0}/content/v2.0/subscriptions/{1}/resourceGroups/{2}" \
                              "/providers/Microsoft.MachineLearningServices/" \
                              "workspaces/{3}/snapshots/sas".format(azureml_globals.service_endpoint,
                                                             azureml_globals.arm_subscription,
                                                             quote(azureml_globals.arm_resource_group, safe=''),
                                                             azureml_globals.arm_workspace_name)
        data = {"SnapshotOrAssetId": snapshot_id}

    sas_tree = _call_snapshot_service(project_service_url, "GetProjectSnapshotFromService",
                                      "Unable to retrieve SaS Urls for project download", data)

    return sas_tree


def _get_snapshot_metadata(snapshot_id):
    """

    Parameters
    ----------
    snapshot_id: str

    Returns
    -------
    dict
    """
    print("[{}] Retrieving snapshot metadata with credentials: {}".format(datetime.datetime.utcnow().isoformat(), snapshot_id))
    project_service_url = azureml_globals.service_endpoint

    snapshot_metadata_url = "{0}/content/v2.0/subscriptions/{1}/resourceGroups/{2}" \
                            "/providers/Microsoft.MachineLearningServices/" \
                            "workspaces/{3}/snapshots/metadataWithCredentials"\
        .format(project_service_url,
                azureml_globals.arm_subscription,
                quote(azureml_globals.arm_resource_group, safe=''),
                azureml_globals.arm_workspace_name)
    
    data = {"SnapshotOrAssetId": snapshot_id}

    # TODO: Remove the old code path for workspace snapshot id (guid style), v2 API actually could handle both.
    if not snapshot_id.startswith('azureml://'):
        data = None
        snapshot_metadata_url = "{0}/content/v2.0/subscriptions/{1}/resourceGroups/{2}" \
                            "/providers/Microsoft.MachineLearningServices/" \
                            "workspaces/{3}/snapshots/{4}/metadataWithCredentials"\
            .format(project_service_url,
                    azureml_globals.arm_subscription,
                    quote(azureml_globals.arm_resource_group, safe=''),
                    azureml_globals.arm_workspace_name,
                    snapshot_id)

    snapshot_metadata = _call_snapshot_service(snapshot_metadata_url, "SnapshotMetadataWithCredentials",
                                               "Failed to get snapshot metadata from service.", data)

    return snapshot_metadata


def _call_snapshot_service(snapshot_api_url, operation_name, error_message, data=None):
    """
    Calls snapshot service and returns json response.
    Parameters
    ----------
    snapshot_api_url: str
    operation_name: str
    error_message: str
    data: Optional[dict]

    Returns
    -------
    dict
    """
    from run_token_provider import RunTokenProvider
    # Default is GET method.
    data = json.dumps(data).encode('utf-8') if isinstance(data, dict) else data
    content_type = "application/json; charset=utf-8" if data is not None else None
    headers=get_default_headers(RunTokenProvider.get_run_token(), content_type=content_type)

    try:
        with ExecutionTimer(operation_name):
            response_read = try_request_with_retries(
                lambda: _read_response(snapshot_api_url, operation_name, headers, data),
                max_attempts=5,
                time_between_retries=.5)
    except Exception as ex:
        print("[{}] {}".format(datetime.datetime.utcnow().isoformat(), error_message))
        raise ex

    # Some versions of json.loads accept type 'bytes'. Others don't.
    # So we always convert to string here.
    response_decode = response_read.decode('utf-8')
    response_json = json.loads(response_decode)
    return response_json


def _make_directory(path):
    try:
        os.makedirs(path)
        if platform.system() == 'Linux' and azureml_globals.is_batchai_target_type:
            os.chmod(path, azureml_globals.default_snapshot_permissions)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise


def _is_file(node):
    return node["sasUrl"] is not None


def _download_tree(root, path_stack):
    if _is_file(root):
        full_path = "/".join(path_stack + [root["name"]])

        try:
            try_request_with_retries(lambda: _download_sas_to_file(full_path, root["sasUrl"], "ReadSnapshotFile"), max_attempts=10, time_between_retries=1)
        except Exception as ex:
            print("")
            print("[{date}]Unable to download project file with filename {filename} ".format(date=datetime.datetime.utcnow().isoformat(), filename=root["name"]))
            raise ex

        if platform.system() == 'Linux' and azureml_globals.is_batchai_target_type:
            os.chmod(full_path, azureml_globals.default_snapshot_permissions)
    else:
        if root["name"] != "":
            path_stack.append(root["name"])
        _make_directory("/".join(path_stack))

        for child in root["children"].values():
            _download_tree(child, path_stack)

        if root["name"] != "":
            path_stack.pop()


def _read_response(request_uri, operation_name, headers={}, data=None):
    request = Request(request_uri, headers=headers, data=data)
    response = urlopen(request, timeout=urlopen_timeout_sec)

    with TimeoutHandler(operation_name, httpread_timeout_sec, env_var_httpread_timeout):
        response_read = response.read()
        return response_read


def _download_sas_to_file(file_path, request_uri, operation_name, headers={}):
    request = Request(request_uri, headers=headers)
    response = urlopen(request, timeout=urlopen_timeout_sec)

    with TimeoutHandler(operation_name, httpread_timeout_sec, env_var_httpread_timeout):
        chunk_size = (1024 * 1024 * 50)  # 50 mb

        with open(file_path, "wb+") as fh:
            while 1:
                chunk = response.read(chunk_size)
                if not chunk:
                    break
                fh.write(chunk)


def _parse_entity_id(snapshot_entity_id):
    # Snapshot EntityId format: "azureml://location/([^/]+)/repositoryId/([^/]+)/type/([^/]+)/objectId/([^/]+)?$"
    snapshot_id_segments = snapshot_entity_id.split("/")
    repository_id = snapshot_id_segments[5]
    object_type = snapshot_id_segments[7]
    object_id = snapshot_id_segments[9]
    entity_id_url = "repositoryId/{0}/type/{1}/objectId/{2}".format(
        repository_id, object_type, object_id)
    return entity_id_url


def _get_snapshot_type(snapshot_metadata):
    """
    Returns snapshot type, either "LocalFiles" or "Git"
    Parameters
    ----------
    snapshot_metadata: dict

    Returns
    -------
    str
    """
    return snapshot_metadata["snapshotMetadata"]["snapshotType"]


def _check_if_git_installed():
    try:
        subprocess.check_call(["git", "--help"])
    except subprocess.CalledProcessError as e:
        raise Exception("Git is not installed. For submitting a run using a git repository, git command is "
                        "required to be installed in the docker image/environment used for submitting the run.")


def _clone_and_checkout_git_repo(snapshot_metadata, path_stack):
    """
    Parameters
    ----------
    snapshot_metadata: dict
    path_stack: list

    Returns
    -------
    """
    # -c core.askPass makes git clone not ask the password if the given password/credentials are wrong.
    # core.askPass=echo redirects to echo to get username and password, which NoOps, and then the
    # command fails if credentials are wrong.
    git_clone_command = ["git", "clone", "-c", "core.askPass=echo"]
    git_repository_commit_dto = snapshot_metadata["snapshotMetadata"]["gitRepositoryCommit"]

    git_repository_url = git_repository_commit_dto["repositoryUri"]
    commit_id = git_repository_commit_dto.get("commitId", None)
    working_directory = git_repository_commit_dto.get("subdirectory", None)

    credential_dto = snapshot_metadata["gitCredential"]
    if credential_dto["credentialType"] == "public":
        git_clone_command.append(git_repository_url)
    else:
        credential_secret = credential_dto["credential"]
        git_url_with_credential = git_repository_url.replace(
            "https://", "https://{}@".format(credential_secret))
        git_clone_command.append(git_url_with_credential)

    # Clone in the temporary directory, and then move the required folders to the current directory.
    with tempfile.TemporaryDirectory() as temporary_clone_directory:
        git_clone_command.append(temporary_clone_directory)

        print("Cloning the git repository. Url {} in temporary directory {}".format(
            git_repository_url, temporary_clone_directory))
        try:
            subprocess.check_output(
                git_clone_command, stderr=subprocess.STDOUT)
        except subprocess.CalledProcessError as e:
            if e.output and "Authentication failed" in e.output.decode("utf-8"):
                # from None swallows the current exception trace, which prevents us from printing wrong/bad credentials.
                # Removing from None, as it is causing issues in hdi runs
                # Confirmed with author that git snapshot service is not enabled yet and removing this is not a blocker issue.
                # TODO: Revisit this code before enabling git snapshot service to prod and do the required changes and testing
                raise Exception("Authentication failed for git repository {}".format(
                    git_repository_url))
            else:
                raise e

        subprocess.check_call(
            ["git", "checkout", commit_id], cwd=temporary_clone_directory)

        # Move required directory from tmp directory git clone to the execution working directory(Current working directory)
        tmp_directory_to_move = temporary_clone_directory
        if working_directory:
            tmp_directory_to_move = os.path.join(
                tmp_directory_to_move, working_directory)

        # If tmp_directory_to_move = /tmp/helloworld and it contains /tmp/helloworld/a and /tmp/helloworld/b
        # then _custom_copy copies a and b, like <dst>/a and <dst>/b
        # shutil.move or shutil.copy include the root folder(helloworld in example) also, so we use custom copy.
        # shutil.move could be efficient, but it includes root folder, so we can't use that.
        # shutil.move(tmp_directory_to_move, os.curdir, copy_function=_custom_copy)
        _custom_copy(tmp_directory_to_move, os.curdir)


def _custom_copy(src, dst):
    for item in os.listdir(src):
        if item == ".git":
            # We don't copy .git folder, as .git/config also contains repository
            # credentials and .git could be big.
            continue
        s = os.path.join(src, item)
        d = os.path.join(dst, item)
        if os.path.isdir(s):
            shutil.copytree(s, d)
        else:
            shutil.copy2(s, d)
