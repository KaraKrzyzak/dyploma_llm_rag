# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import json
import datetime


class FailedToParseErrorResponseError(Exception):
    pass


def get_error_response_from_stream_or_error(stream):
    if stream is None:
        raise FailedToParseErrorResponseError()

    try:
        error_response = _parse_and_validate_json(stream)
    except (json.JSONDecodeError, FailedToParseErrorResponseError):
        raise FailedToParseErrorResponseError()

    return error_response


def get_error_response_dict(error_message, error_code=None):
    # We're using UserError as the default as these utilities only get called during environment preparation
    if error_code is None:
        error_code = "UserError"

    error_response = {
        "AzureMLErrorResponse": {
            "Error": {
                "Code": error_code,
                "Message": error_message
            },
            "Time": datetime.datetime.utcnow().isoformat()
        }
    }

    return error_response


def _parse_and_validate_json(stream):
    parsed_json = json.load(stream)
    if "AzureMLErrorResponse" not in parsed_json or "Error" not in parsed_json["AzureMLErrorResponse"]:
        raise FailedToParseErrorResponseError()
    return parsed_json["AzureMLErrorResponse"]
